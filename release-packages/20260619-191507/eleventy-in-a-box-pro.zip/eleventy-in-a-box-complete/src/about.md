---
featureImage: /images/placeholder-featured.svg
featureImageCaption: Eleventy in a Box. An Eleventy starter kit by Andy Clarke.
layout: layouts/about.html
metaDesc:
permalink: /about/
title: Stuff Industries Incorporated

lede: |
  <p class="alt-lede">Most development doesn’t need more complexity—it just needs a solid start.</p>

aside: |

---

Established sometime in the mid-to-late twentieth century (records vary.) Stuff Industries began by manufacturing dependable components for projects that required precision, structure, and a tolerance for the unexpected.

As our catalogue shifted to digital products, Stuff Industries adapted. Our focus remained reducing friction, removing unnecessary complexity, and providing foundations others can build on.

Eleventy In A Box is a natural extension of that philosophy. It takes everything we&#8217;ve learned about developing with Eleventy and packages it into a dependable starting point. No unnecessary extras. No hidden surprises. Just a system that works, ready to be shaped into something more.