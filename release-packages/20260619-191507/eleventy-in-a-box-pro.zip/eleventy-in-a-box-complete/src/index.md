---
featureImage: /images/placeholder-featured.svg
featureImageCaption: Eleventy in a Box. An Eleventy starter kit by Andy Clarke.
layout: layouts/home.html
metaDesc: An Eleventy starter kit by Andy Clarke.
title: Eleventy in a Box—just add water

lede: |
  <p class="alt-lede">Everything you need, nothing you don’t.</p>

aside: |

---

Eleventy In A Box is a ready-to-use website development boilerplate. Open the box, add your styles, and shape it into something distinctive, without wasting time on repetitive tasks

### Optional add-ons include

- Blog/news
- Case studies
- Changelog
- FAQs
- Portfolio
- Services
- Team
- Testimonials
