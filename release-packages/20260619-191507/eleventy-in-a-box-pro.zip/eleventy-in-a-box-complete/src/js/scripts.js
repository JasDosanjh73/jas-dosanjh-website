(() => {
const storageKey = "user-color-scheme";
const root = document.documentElement;
const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)");
const toggle = document.querySelector("[data-mode-toggle]");
const toggleText = document.querySelector("[data-mode-toggle-text]");
const status = document.querySelector("[data-mode-status]");

if (!toggle || !toggleText || !status) {
return;
}

function getSystemMode() {
return mediaQuery.matches ? "dark" : "light";
}

function getStoredMode() {
const storedMode = window.localStorage.getItem(storageKey);

if (storedMode === "light" || storedMode === "dark") {
return storedMode;
}

return null;
}

function setMode(mode, announce) {
const nextLabel = mode === "dark" ? "Use light mode" : "Use dark mode";

root.setAttribute("data-color-mode", mode);
toggle.setAttribute("aria-pressed", String(mode === "dark"));
toggleText.textContent = nextLabel;

if (announce) {
status.textContent = mode === "dark" ? "Dark mode enabled" : "Light mode enabled";
}
}

function applyMode(mode, persist) {
setMode(mode, true);

if (persist) {
window.localStorage.setItem(storageKey, mode);
root.setAttribute("data-user-color-scheme", mode);
return;
}

root.removeAttribute("data-user-color-scheme");
window.localStorage.removeItem(storageKey);
}

function getCurrentMode() {
return root.getAttribute("data-color-mode") || getStoredMode() || getSystemMode();
}

toggle.hidden = false;
setMode(getCurrentMode(), false);

toggle.addEventListener("click", () => {
const nextMode = getCurrentMode() === "dark" ? "light" : "dark";
applyMode(nextMode, true);
});

mediaQuery.addEventListener("change", () => {
if (getStoredMode()) {
return;
}

setMode(getSystemMode(), false);
});
})();

(() => {
const menus = document.querySelectorAll("[data-navigation-menu]");

if (menus.length === 0) {
return;
}

menus.forEach((menu) => {
const closeButton = menu.querySelector("[data-navigation-menu-close]");
const dialog = menu.querySelector("[data-navigation-menu-dialog]");
const firstLink = menu.querySelector("[data-navigation-menu-first-link]");
const toggle = menu.querySelector("[data-navigation-menu-toggle]");

if (!closeButton || !dialog || !toggle) {
return;
}

function setExpanded(isExpanded) {
toggle.setAttribute("aria-expanded", String(isExpanded));
}

function focusToggle() {
window.requestAnimationFrame(() => {
toggle.focus();
});
}

function openMenu() {
if (dialog.open) {
return;
}

if (typeof dialog.showModal === "function") {
dialog.showModal();
} else {
dialog.setAttribute("open", "");
}

setExpanded(true);
window.requestAnimationFrame(() => {
(firstLink || closeButton).focus();
});
}

function closeMenu() {
if (!dialog.open) {
return;
}

if (typeof dialog.close === "function") {
dialog.close();
} else {
dialog.removeAttribute("open");
}

setExpanded(false);
focusToggle();
}

toggle.addEventListener("click", () => {
if (dialog.open) {
closeMenu();
return;
}

openMenu();
});

closeButton.addEventListener("click", closeMenu);

dialog.addEventListener("cancel", () => {
setExpanded(false);
focusToggle();
});

dialog.addEventListener("close", () => {
setExpanded(false);
});

dialog.addEventListener("click", (event) => {
const { bottom, left, right, top } = dialog.getBoundingClientRect();
const clickedBackdrop = event.clientX < left || event.clientX > right || event.clientY < top || event.clientY > bottom;

if (!clickedBackdrop) {
return;
}

closeMenu();
});
});
})();
